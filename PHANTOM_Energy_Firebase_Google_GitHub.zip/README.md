# PHANTOM Energy — Firebase Authentication + Google

## Conteúdo

- `index.html`: página inicial, acesso e painel PHANTOM.
- `404.html`: página de erro do GitHub Pages.
- `politica-de-privacidade.html`: política atualizada para Firebase Authentication.
- `cookies.html`: armazenamento local e autenticação Firebase/Google.
- `termos-de-uso.html`: termos atualizados.
- `assets/`: logotipos e símbolos da marca.
- `.github/workflows/pages.yml`: publicação automatizada no GitHub Pages.

## Autenticação conectada

O `index.html` está configurado para o projeto Firebase `phantom-f90fe` e usa:

- Firebase Authentication por e-mail e senha, com verificação do endereço;
- Google Sign-In (janela pop-up em desktop e redirecionamento em telas menores);
- persistência de sessão no navegador;
- recuperação de senha por e-mail;
- edição de nome e pedido de alteração do e-mail com verificação.

A configuração Web do Firebase fica no HTML. `apiKey`, `authDomain`, `projectId` e `appId` são identificadores públicos do aplicativo Web, não substituem regras de segurança. Nunca inclua chaves privadas, service account JSON ou credenciais administrativas no site.

## Importante sobre os dados

Firebase Authentication gerencia as contas e as credenciais. **As investigações, relatórios e preferências do PHANTOM continuam armazenados localmente no navegador nesta versão**; não existe sincronização dos relatórios entre dispositivos nem banco de dados em nuvem para investigações ainda.

## Como testar localmente (não abra por `file://`)

O Firebase Authentication precisa de uma origem web autorizada. Como `localhost` já aparece nos domínios autorizados do projeto:

1. Extraia o ZIP para uma pasta normal.
2. Abra o terminal nessa pasta (onde está `index.html`).
3. No Windows, você pode dar dois cliques em `INICIAR_TESTE_LOCAL.bat` (ou executar `python -m http.server 8000` no terminal).
4. No navegador, abra `http://localhost:8000`.
5. Teste criação de conta com e-mail, confirmação recebida, login, senha incorreta, recuperação e Google Sign-In.

Também é possível usar a extensão Live Server do Visual Studio Code, desde que o endereço seja `http://localhost`.

## Configuração Firebase já necessária no Console

- Authentication → Método de login: E-mail/Senha ativado.
- Authentication → Método de login: Google ativado e e-mail de suporte selecionado.
- Authentication → Configurações → Domínios autorizados: `localhost`, `phantom-f90fe.firebaseapp.com` e `phantom-f90fe.web.app` já aparecem configurados conforme a captura enviada.
- Depois de publicar, adicione também o domínio personalizado, se houver.

## Publicar no GitHub Pages

1. Envie todo o conteúdo desta pasta para a raiz do repositório, mantendo as pastas.
2. Em **Settings → Pages**, selecione **GitHub Actions**.
3. Aguarde a execução do workflow em `.github/workflows/pages.yml`.
4. Adicione a URL `https://<usuario>.github.io` ou o domínio real em **Authentication → Configurações → Domínios autorizados**.
5. Teste cadastro, confirmação, login, Google, recuperação, logout, páginas legais e página 404 no endereço HTTPS publicado.

## Antes de divulgar

- Complete na Política de Privacidade a identificação legal do controlador e confirme o canal de atendimento.
- Revise as páginas legais de acordo com as práticas reais do PHANTOM.
- As imagens remotas continuam sujeitas à escolha de consentimento do visitante.
- Teste o fluxo Google no domínio publicado, pois o Firebase bloqueia origens não autorizadas.
